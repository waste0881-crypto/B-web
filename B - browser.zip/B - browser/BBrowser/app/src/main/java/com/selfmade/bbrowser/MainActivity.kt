package com.selfmade.bbrowser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var privateMode = false
    private var tabs = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = false
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "BB")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun search(text: String) {
            runOnUiThread {
                val q = text.trim()
                if (q.isNotEmpty()) {
                    val url = if (q.startsWith("https://") || q.startsWith("http://")) q
                    else if (q.contains(".") && !q.contains(" ")) "https://$q"
                    else "https://www.google.com/search?q=" + java.net.URLEncoder.encode(q, "UTF-8")
                    web.loadUrl(url)
                }
            }
        }
        @JavascriptInterface fun home() { runOnUiThread { web.loadUrl("file:///android_asset/index.html") } }
        @JavascriptInterface fun ai() { runOnUiThread { web.loadUrl("https://chatgpt.com/") } }
        @JavascriptInterface fun back() { runOnUiThread { if (web.canGoBack()) web.goBack() else home() } }
        @JavascriptInterface fun newTab() { runOnUiThread { tabs++; Toast.makeText(this@MainActivity, "Tab $tabs திறக்கப்பட்டது", Toast.LENGTH_SHORT).show() } }
        @JavascriptInterface fun togglePrivate() {
            runOnUiThread {
                privateMode = !privateMode
                if (privateMode) {
                    web.clearHistory(); web.clearCache(true)
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                }
                Toast.makeText(this@MainActivity, if (privateMode) "Private mode ON" else "Private mode OFF", Toast.LENGTH_SHORT).show()
            }
        }
        @JavascriptInterface fun vpn() {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("VPN பாதுகாப்பு")
                    .setMessage("உண்மையான VPN இணைப்புக்கு நம்பகமான VPN சேவை மற்றும் அதன் சேவையக விவரங்கள் தேவை. இந்த முதல் பதிப்பில் VPN சேவையகம் சேர்க்கப்படவில்லை; ஆகவே VPN இயக்கப்பட்டதாகக் காட்டமாட்டோம்.")
                    .setPositiveButton("சரி", null).show()
            }
        }
        @JavascriptInterface fun servers() {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity).setTitle("VPN சேவையகங்கள்")
                    .setItems(arrayOf("இந்தியா", "சிங்கப்பூர்", "ஜெர்மனி", "அமெரிக்கா")) { _, which ->
                        Toast.makeText(this@MainActivity, "சேவையகத்தைப் பயன்படுத்த VPN வழங்குநர் இணைப்பு தேவை.", Toast.LENGTH_LONG).show()
                    }.setNegativeButton("மூடு", null).show()
            }
        }
        @JavascriptInterface fun menu() {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity).setTitle("B.Browser")
                    .setItems(arrayOf("முகப்பு", "பின்னால்", "புதிய Tab", "AI Chat", "தனிப்பட்ட உலாவல்", "VPN தகவல்")) { _, i ->
                        when (i) { 0 -> home(); 1 -> back(); 2 -> newTab(); 3 -> ai(); 4 -> togglePrivate(); 5 -> vpn() }
                    }.show()
            }
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
